<?php

error_reporting(0);
$servername = "localhost"; // Do not change this
$dbname = "zero_db"; // Your db Name goes here
$dbuser = "zero_user"; //Your db Username goes here.
$dbpass = "AnonymousUser1."; //Database Password goes here

// admin panel password
$admin_password = "ad1234"; // make sure to change this one
$Your_URL = " "; //IMPORTANT! please put your link here, without the https:// or www, e.g binanceaccounts.info, binance-account.info

// Live Panel Purchase / Authorisation code
$Purchase_Key = "EnterPurchaseCode"; // This is needed or else panel will not work. Purchase only from - the coders

?>